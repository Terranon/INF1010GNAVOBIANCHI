
#include <iostream>
#include "groupe.h"

using namespace std; 

int main(int argc, const char * argv[]) {
    cout << "\t \tBienvenue sur PolyCount " << endl << " *****************************************" << endl;
    // Creer un  groupe pour  6 depenses et 4 utilisateurs.
  
    
    // Creer 5 utlisateurs.

    
    //Creer 7 dépenses.
    

    
    //ajouter les utilisateurs au groupe
    

    //ajouter les depenses au groupe
    

    
    //calculer le total du grouoe et de chaque utilisateur

    //Afficher  le groupe

    
    //Equilibrer les comptes

    //Afficher le groupe

   
    //terminer le programme correctement

}
